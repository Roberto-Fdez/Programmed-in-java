// Roberto Fernández del Barrio. //
// DNI: 43232819H //
package prouex03;

public class eina {
    // Classe base Eina
    private double pes;
    private String material;
    private String nom;

    // Constructor
    public eina(double pes, String material) {
        this.pes = pes;
        this.material = material;
    }

    // Getters i setters
    public double getPes() {
        return pes;
    }

    public void setPes(double pes) {
        this.pes = pes;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    // Mètode utilitzar i nom
    public void utilitzar() {
        System.out.println("Utilitzant l'eina.");
    }

    public String getNom() {
        return nom;
    }
}