// Roberto Fernández del Barrio. //
// DNI: 43232819H //
package prouex03;

//Extends del pare al fill + el nom de l'eina.
public class serra extends eina {
    private String nom = "Serra";

    // Constructor
    // Possam el pes i el material del que està feta l'eina.

    public serra(double pes, String material) {
        super(pes, material);
    }

    // Herencia del pare.
    // Realitzam el override per fer la herencia del pare al fill donant que farà ús
    // de l'eina i retornarà el seu nom.

    @Override
    public void utilitzar() {
        System.out.println("Tallant amb la serra.");
    }

    @Override
    public String getNom() {
        return nom;
    }
}