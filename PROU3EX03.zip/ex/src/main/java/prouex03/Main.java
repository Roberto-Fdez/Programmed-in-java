// Roberto Fernández del Barrio. //
// DNI: 43232819H //
package prouex03;

public class Main {
    public static void main(String[] args) {
        // Crear objectes de cada eina de la que farem ús.
        eina martell = new martell(1.5, "Metall");
        eina destornillador = new destornillador(0.7, "Acer");
        eina serra = new serra(2.3, "Fusta");

        // Mostrar informació de cada eina.
        mostrarEina(martell);
        mostrarEina(destornillador);
        mostrarEina(serra);
    }

    // Mostrar per pantalla el missatge que es diu a l'enunciat.
    public static void mostrarEina(eina eina) {
        eina.utilitzar();
        System.out.println("La eina es de " + eina.getMaterial() + " , el seu pes es de " + eina.getPes()
                + "kg i la eina es un/a " + eina.getNom());
        System.out.println("----------------------------------------------------------------------------");
    }
}